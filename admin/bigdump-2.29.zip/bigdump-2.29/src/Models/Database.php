<?php

declare(strict_types=1);

namespace BigDump\Models;

use BigDump\Config\Config;
use mysqli;
use mysqli_result;
use RuntimeException;

/**
 * Database Class - MySQL Connection Manager
 *
 * This class encapsulates the MySQLi connection and provides
 * secure methods for query execution
 *
 * Features (v2.25+):
 * - Persistent connections support (optional, disabled by default)
 * - Connection validation before reuse
 *
 * @package BigDump\Models
 * @author  w3spi5
 */
class Database
{
    /**
     * MySQLi Instance
     * @var mysqli|null
     */
    private ?mysqli $connection = null;

    /**
     * Configuration
     * @var Config
     */
    private Config $config;

    /**
     * Last error
     * @var string
     */
    private string $lastError = '';

    /**
     * Number of executed queries
     * @var int
     */
    private int $queryCount = 0;

    /**
     * Test mode enabled
     * @var bool
     */
    private bool $testMode = false;

    /**
     * Whether persistent connections are enabled
     * @var bool
     */
    private bool $persistentConnections = false;

    /**
     * Constructor
     *
     * @param Config $config Configuration
     */
    public function __construct(Config $config)
    {
        $this->config = $config;
        $this->testMode = $config->get('test_mode', false);
        $this->persistentConnections = (bool) $config->get('persistent_connections', false);
    }

    /**
     * Establishes the database connection
     *
     * Supports persistent connections (v2.25+) when enabled via config.
     * Persistent connections reduce reconnection overhead for large imports
     * but should be used carefully on shared hosting to avoid connection pool exhaustion.
     *
     * @return bool True if connection succeeds
     * @throws RuntimeException If connection fails
     */
    public function connect(): bool
    {
        if ($this->testMode) {
            return true;
        }

        if ($this->connection !== null) {
            // Validate existing connection before reuse
            if ($this->validateConnection()) {
                return true;
            }
            // Connection invalid, close and reconnect
            $this->close();
        }

        $db = $this->config->getDatabase();

        // Disable MySQLi error reporting to handle errors manually
        mysqli_report(MYSQLI_REPORT_OFF);

        // Parse server to extract host, port, socket
        $server = $this->parseServer($db['server']);

        // For persistent connections, prepend 'p:' to hostname
        // This tells MySQLi to use persistent connection
        $host = $server['host'];
        if ($this->persistentConnections) {
            $host = 'p:' . $host;
        }

        // Establish connection
        $this->connection = @new mysqli(
            $host,
            $db['username'],
            $db['password'],
            $db['name'],
            $server['port'],
            $server['socket']
        );

        if ($this->connection->connect_error) {
            $this->lastError = $this->connection->connect_error;
            $this->connection = null;
            throw new RuntimeException("Database connection failed: {$this->lastError}");
        }

        // Set charset
        if (!empty($db['charset'])) {
            // Validate charset name to prevent SQL injection
            // MySQL charset names only contain alphanumeric characters
            $safeCharset = preg_replace('/[^a-zA-Z0-9]/', '', $db['charset']);
            if ($safeCharset !== $db['charset']) {
                throw new RuntimeException("Invalid charset name: {$db['charset']}");
            }

            if (!$this->connection->set_charset($safeCharset)) {
                // Fallback with SET NAMES (no quotes/backticks - charset is already validated)
                $this->connection->query("SET NAMES {$safeCharset}");
            }
        }

        // Execute pre-queries
        $this->executePreQueries();

        return true;
    }

    /**
     * Validates existing connection before reuse
     *
     * For persistent connections, the connection might have been closed
     * by the server due to timeout. This method validates the connection
     * is still alive and usable.
     *
     * @return bool True if connection is valid and usable
     */
    private function validateConnection(): bool
    {
        if ($this->connection === null) {
            return false;
        }

        // Use ping() to check if connection is alive
        // This will attempt to reconnect if the connection was lost
        // and mysqli.reconnect is enabled
        try {
            return @$this->connection->ping();
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Parses server string to extract host, port and socket
     *
     * @param string $server Server string
     * @return array{host: string, port: int, socket: string} Parsed components
     */
    private function parseServer(string $server): array
    {
        $result = [
            'host' => 'localhost',
            'port' => 3306,
            'socket' => '',
        ];

        if (empty($server)) {
            return $result;
        }

        // Check if it's a Unix socket
        if (str_contains($server, '/')) {
            // Format: hostname:/path/to/socket or :/path/to/socket
            $parts = explode(':', $server, 2);
            if (count($parts) === 2) {
                $result['host'] = $parts[0] ?: 'localhost';
                $result['socket'] = $parts[1];
            } else {
                $result['socket'] = $server;
            }
        } elseif (str_contains($server, ':')) {
            // Format: hostname:port
            $parts = explode(':', $server);
            $result['host'] = $parts[0];
            $result['port'] = (int) ($parts[1] ?? 3306);
        } else {
            $result['host'] = $server;
        }

        return $result;
    }

    /**
     * Executes configured pre-queries
     *
     * @return void
     * @throws RuntimeException If a pre-query fails
     */
    private function executePreQueries(): void
    {
        $preQueries = $this->config->get('pre_queries', []);

        if (!is_array($preQueries) || empty($preQueries)) {
            return;
        }

        foreach ($preQueries as $query) {
            if (!$this->query($query)) {
                throw new RuntimeException("Pre-query failed: {$query}\nError: {$this->lastError}");
            }
        }
    }

    /**
     * Executes configured post-queries (called after import completion)
     * Non-fatal: logs errors but continues
     *
     * @return void
     */
    public function executePostQueries(): void
    {
        $postQueries = $this->config->get('post_queries', []);

        if (!is_array($postQueries) || empty($postQueries)) {
            return;
        }

        foreach ($postQueries as $query) {
            // Non-fatal: we attempt to restore constraints but don't throw
            $this->query($query);
        }
    }

    /**
     * Executes an SQL query
     *
     * @param string $query SQL query
     * @return mysqli_result|bool Query result
     */
    public function query(string $query): mysqli_result|bool
    {
        if ($this->testMode) {
            $this->queryCount++;
            return true;
        }

        if ($this->connection === null) {
            $this->lastError = 'Not connected to database';
            return false;
        }

        $result = $this->connection->query($query);

        if ($result === false) {
            $this->lastError = $this->connection->error;
            return false;
        }

        $this->queryCount++;
        $this->lastError = '';

        return $result;
    }

    /**
     * Retrieves current connection charset
     *
     * @return string Charset or empty string
     */
    public function getConnectionCharset(): string
    {
        if ($this->testMode || $this->connection === null) {
            return $this->config->get('db_connection_charset', 'utf8mb4');
        }

        $result = $this->connection->query("SHOW VARIABLES LIKE 'character_set_connection'");

        if ($result instanceof mysqli_result) {
            $row = $result->fetch_assoc();
            $result->free();

            if ($row && isset($row['Value'])) {
                return $row['Value'];
            }
        }

        return '';
    }

    /**
     * Checks if connection is established
     *
     * @return bool True if connected
     */
    public function isConnected(): bool
    {
        if ($this->testMode) {
            return true;
        }

        return $this->connection !== null && $this->connection->ping();
    }

    /**
     * Retrieves last error
     *
     * @return string Error message
     */
    public function getLastError(): string
    {
        return $this->lastError;
    }

    /**
     * Retrieves number of executed queries
     *
     * @return int Number of queries
     */
    public function getQueryCount(): int
    {
        return $this->queryCount;
    }

    /**
     * Escapes a string for SQL usage
     *
     * @param string $string String to escape
     * @return string Escaped string
     */
    public function escape(string $string): string
    {
        if ($this->testMode || $this->connection === null) {
            return addslashes($string);
        }

        return $this->connection->real_escape_string($string);
    }

    /**
     * Retrieves last insert ID
     *
     * @return int ID
     */
    public function getLastInsertId(): int
    {
        if ($this->testMode || $this->connection === null) {
            return 0;
        }

        return (int) $this->connection->insert_id;
    }

    /**
     * Retrieves number of affected rows
     *
     * @return int Number of rows
     */
    public function getAffectedRows(): int
    {
        if ($this->testMode || $this->connection === null) {
            return 0;
        }

        return (int) $this->connection->affected_rows;
    }

    /**
     * Closes the connection
     *
     * Note: For persistent connections, close() doesn't actually close
     * the connection - it returns it to the connection pool.
     *
     * @return void
     */
    public function close(): void
    {
        if ($this->connection !== null) {
            $this->connection->close();
            $this->connection = null;
        }
    }

    /**
     * Retrieves database name
     *
     * @return string Database name
     */
    public function getDatabaseName(): string
    {
        return $this->config->get('db_name', '');
    }

    /**
     * Retrieves server name
     *
     * @return string Server name
     */
    public function getServerName(): string
    {
        return $this->config->get('db_server', 'localhost');
    }

    /**
     * Checks if test mode is enabled
     *
     * @return bool True if test mode
     */
    public function isTestMode(): bool
    {
        return $this->testMode;
    }

    /**
     * Checks if persistent connections are enabled
     *
     * @return bool True if persistent connections enabled
     */
    public function isPersistentConnections(): bool
    {
        return $this->persistentConnections;
    }

    /**
     * Destructor - closes the connection
     */
    public function __destruct()
    {
        $this->close();
    }
}
