<?php
// never executed by the reviewer
throw new RuntimeException('executed');
